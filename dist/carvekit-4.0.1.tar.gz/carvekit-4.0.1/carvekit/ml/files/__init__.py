from pathlib import Path

carvekit_dir = Path.home().joinpath('.carvekit')
checkpoints_dir = carvekit_dir.joinpath('checkpoints')
